"""Local read-only SSH wrapper; retains exact remote receipt stdout locally."""
import hashlib, json, pathlib, subprocess
root = pathlib.Path(__file__).resolve().parent
script = (root / 'preflight-host-read.py').read_bytes()
output = root / 'host-preflight-20261020.json'
if output.exists(): raise SystemExit('refusing to overwrite evidence')
command = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'StrictHostKeyChecking=yes',
           'root@100.97.129.48', 'python3', '-']
result = subprocess.run(command, input=script, capture_output=True, timeout=35)
if len(result.stdout) > 2 * 1024 * 1024 or len(result.stderr) > 65536: raise SystemExit('SSH receipt bound exceeded')
if result.returncode: raise SystemExit('SSH preflight failed: ' + result.stderr.decode(errors='replace'))
value = json.loads(result.stdout)
with output.open('xb') as f: f.write(result.stdout)
print(json.dumps({'path': str(output), 'bytes': len(result.stdout), 'sha256': hashlib.sha256(result.stdout).hexdigest(),
    'scriptSha256': hashlib.sha256(script).hexdigest(), 'host': value['host'], 'process': value['process'],
    'files': value['files'], 'publicGenesisCount': len(value['publicGenesis']),
    'rpcHeads': [{key: r['parsed'].get(key) for key in ['head_block_num', 'last_irreversible_block_num', 'chain_id', 'server_full_version_string']}
                 for r in value['rpc']]}, indent=2))
