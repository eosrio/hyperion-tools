"""Detach exact public bytes from immutable capture receipts; never synthesize input."""
import base64, hashlib, json, pathlib
root = pathlib.Path(__file__).resolve().parent
host = json.loads((root / 'host-preflight-20261020.json').read_bytes())
ship = json.loads((root / 'ship-preflight-20261020.json').read_bytes())
output = root / 'raw'
output.mkdir(exist_ok=False)
members = []
def write(name, value):
    raw = base64.b64decode(value['base64'], validate=True)
    assert len(raw) == value['bytes'] and hashlib.sha256(raw).hexdigest() == value['sha256']
    path = output / name
    with path.open('xb') as f: f.write(raw)
    members.append({'path': path.relative_to(root).as_posix(), 'bytes': len(raw), 'sha256': value['sha256']})
write('ship-schema.abi.json', ship['schema'])
for message in ship['messages']:
    write(message['kind'] + '-request.bin', message['request'])
    write(message['kind'] + '-result.bin', message['response'])
    for name, section in message.get('sections', {}).items(): write(message['kind'] + '-' + name + '.bin', section)
    if 'ack' in message: write(message['kind'] + '-ack.bin', message['ack'])
for i, record in enumerate(host['rpc']):
    write('host-get-info-' + str(i + 1) + '-request.json', record['request'])
    write('host-get-info-' + str(i + 1) + '-response.json', record['response'])
for i, record in enumerate(ship['rpc']):
    write('ship-rpc-' + str(i + 1) + '-request.json', record['request'])
    write('ship-rpc-' + str(i + 1) + '-response.json', record['response'])
for i, record in enumerate(host['publicGenesis']): write('genesis-public-' + str(i + 1) + '.json', record)
for i, record in enumerate(ship['transport']): write('websocket-frame-' + str(i + 1) + '-' + record['direction'] + '.bin', record)
write('websocket-upgrade-request.txt', ship['websocketUpgrade']['request'])
write('websocket-upgrade-response.txt', ship['websocketUpgrade']['responseHeaders'])
index = {'schemaVersion': 1, 'scope': 'verbatim decoded byte copies from retained actual6508 public receipts',
         'sourceRevision': ship['sourceRevision'], 'chainId': ship['chainId'], 'members': members}
manifest = root / 'raw-receipts-manifest.json'
with manifest.open('xb') as f: f.write((json.dumps(index, indent=2) + '\n').encode())
print(json.dumps({'members': len(members), 'manifest': str(manifest), 'sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
                  'hostObservedAt': host['observedAt'], 'shipStartedAt': ship['startedAt'], 'shipCompletedAt': ship['completedAt']}, indent=2))
