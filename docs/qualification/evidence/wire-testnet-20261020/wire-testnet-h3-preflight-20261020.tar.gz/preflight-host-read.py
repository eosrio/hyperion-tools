"""Owned Hyperion-3 Wire source: bounded read-only identity/RPC observations."""
import base64, datetime, hashlib, json, os, pathlib, subprocess, time, urllib.request

ROOT = pathlib.Path('/data/chains/wire-testnet-ship')
BIN = pathlib.Path('/opt/wire-sysio-1.0.0-6508c9e8/bin')
EXPECTED_REV = '6508c9e8f4044df8d5acb082a7af3be6a80cd9a0'
EXPECTED_CHAIN = '9ccd94e823fda51363bd4265ad618a909c4985c445078c79f8d030fe9697b71d'

def sha(value): return hashlib.sha256(value).hexdigest()
def blob(value): return {'bytes': len(value), 'sha256': sha(value), 'base64': base64.b64encode(value).decode()}
def read_bounded(path, limit):
    with path.open('rb') as f:
        value = f.read(limit + 1)
    if len(value) > limit: raise RuntimeError('bounded read exceeded: ' + str(path))
    return value
def file_hash(path, limit):
    before = path.stat()
    if before.st_size > limit: raise RuntimeError('file size bound exceeded: ' + str(path))
    digest = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): digest.update(chunk)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
        raise RuntimeError('file changed while hashing: ' + str(path))
    return {'path': str(path), 'bytes': after.st_size, 'sha256': digest.hexdigest(), 'inode': after.st_ino,
            'mtimeNs': after.st_mtime_ns, 'stableDuringRead': True}

def rpc(path):
    request = b'{}'
    url = 'http://127.0.0.1:58271/v1/chain/' + path
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with urllib.request.urlopen(urllib.request.Request(url, data=request, headers={'Content-Type': 'application/json'}), timeout=5) as response:
        raw = response.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024: raise RuntimeError('RPC body too large')
        status = response.status
        content_type = response.headers.get('Content-Type')
    value = json.loads(raw)
    if value.get('chain_id') != EXPECTED_CHAIN: raise RuntimeError('unselected live chain')
    if EXPECTED_REV not in value.get('server_full_version_string', ''): raise RuntimeError('unselected live revision')
    return {'url': url, 'startedAt': started, 'status': status, 'contentType': content_type,
            'request': blob(request), 'response': blob(raw), 'parsed': value}

candidates = subprocess.run(['pgrep', '-x', 'nodeop'], capture_output=True, text=True, timeout=3)
pids = [int(value) for value in candidates.stdout.split()]
if len(pids) > 8: raise RuntimeError('nodeop process candidate bound exceeded')
selected = []
for pid in pids:
    try:
        if os.readlink('/proc/' + str(pid) + '/exe') == str(BIN / 'nodeop'): selected.append(pid)
    except FileNotFoundError: pass
if len(selected) != 1: raise RuntimeError('exact selected nodeop binary must identify one live process')
PID = selected[0]
proc = pathlib.Path('/proc') / str(PID)
exe = os.readlink(proc / 'exe')
if exe != str(BIN / 'nodeop'): raise RuntimeError('PID executable identity changed')
stat_start = read_bounded(proc / 'stat', 8192).decode().rsplit(')', 1)[1].split()[19]
argv = read_bounded(proc / 'cmdline', 65536).split(b'\0')
def arg_value(flag):
    encoded = flag.encode()
    for index, part in enumerate(argv):
        if part == encoded and index + 1 < len(argv): return argv[index+1].decode()
        if part.startswith(encoded + b'='): return part[len(encoded)+1:].decode()
    return None
selected_args = {name: arg_value(name) for name in ['--data-dir', '--config-dir', '--genesis-json', '--http-server-address', '--state-history-endpoint']}
if selected_args['--data-dir'] != str(ROOT) or selected_args['--config-dir'] != str(ROOT):
    raise RuntimeError('selected process uses unexpected owned config/data root')

public_keys = {'http-server-address', 'state-history-endpoint', 'p2p-listen-endpoint', 'plugin',
               'trace-history', 'chain-state-history', 'state-history-stride', 'max-retained-history-files',
               'state-history-retain-blocks', 'state-history-dir', 'disable-replay-opts', 'read-mode',
               'validation-mode', 'http-validate-host', 'http-max-response-time-ms'}
configuration = []
config = ROOT / 'config.ini'
if config.is_file():
    # Retain only an explicit public allowlist. Never export raw config/provider values.
    with config.open('r', encoding='utf8') as f:
        for line in f:
            clean = line.strip()
            if not clean or clean.startswith(('#', ';')) or '=' not in clean: continue
            key, value = (part.strip() for part in clean.split('=', 1))
            if key in public_keys: configuration.append([key, value])
    public_config = json.dumps(configuration, separators=(',', ':'), ensure_ascii=False).encode()
else: public_config = b'[]'

files = [file_hash(pathlib.Path('/proc') / str(PID) / 'exe', 512 * 1024 * 1024)]
clio = BIN / 'clio'
if clio.is_file(): files.append(file_hash(clio, 512 * 1024 * 1024))
public_genesis = []
for name in ['genesis.json', 'genesis.public.json']:
    path = ROOT / name
    if path.is_file():
        raw = read_bounded(path, 128 * 1024)
        value = json.loads(raw)
        allowed_genesis = {'initial_timestamp', 'initial_key', 'initial_finalizer_key', 'initial_configuration', 'initial_chain_id'}
        if not set(value).issubset(allowed_genesis): raise RuntimeError('genesis has unreviewed fields; not exported')
        public_genesis.append({'path': str(path), **blob(raw), 'parsed': value})
for name in ['version.txt', 'VERSION', 'source-revision.txt', 'build-info.json']:
    path = BIN.parent / name
    if path.is_file():
        raw = read_bounded(path, 16384)
        files.append({'path': str(path), **blob(raw)})
infos = [rpc('get_info')]
time.sleep(2)
infos.append(rpc('get_info'))
if os.readlink(proc / 'exe') != exe or read_bounded(proc / 'stat', 8192).decode().rsplit(')', 1)[1].split()[19] != stat_start:
    raise RuntimeError('selected process changed during observation')
print(json.dumps({'schemaVersion': 1, 'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'actual-6508-testnet-read-only', 'expectedSourceRevision': EXPECTED_REV, 'expectedChainId': EXPECTED_CHAIN,
    'host': os.uname().nodename, 'process': {'pid': PID, 'executable': exe, 'startTicks': stat_start,
        'cmdlineSha256': sha(b'\0'.join(argv)), 'selectedArguments': selected_args,
        'cgroup': read_bounded(proc / 'cgroup', 16384).decode()},
    'files': files, 'publicGenesis': public_genesis,
    'publicConfig': {'path': str(config), 'selection': 'explicit nonsecret allowlist; not a hash/copy of full config',
                     'entries': configuration, 'canonicalSha256': sha(public_config)},
    'rpc': infos, 'bounds': {'rpcTimeoutSeconds': 5, 'rpcBodyBytes': 1048576, 'sampleGapSeconds': 2},
    'changes': []}, separators=(',', ':')))
