import hashlib, json, pathlib, subprocess
root = pathlib.Path(__file__).resolve().parent
script = (root / 'preflight-ship-read.py').read_bytes()
output = root / 'ship-preflight-20261020.json'
if output.exists(): raise SystemExit('refusing to overwrite evidence')
result = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', '-o', 'StrictHostKeyChecking=yes',
                         'root@100.97.129.48', 'python3', '-'], input=script, capture_output=True, timeout=50)
if len(result.stdout) > 20 * 1024 * 1024 or len(result.stderr) > 65536: raise SystemExit('SSH receipt bound exceeded')
if result.returncode: raise SystemExit('SSH preflight failed: ' + result.stderr.decode(errors='replace'))
value = json.loads(result.stdout)
with output.open('xb') as f: f.write(result.stdout)
print(json.dumps({'path': str(output), 'bytes': len(result.stdout), 'sha256': hashlib.sha256(result.stdout).hexdigest(),
    'scriptSha256': hashlib.sha256(script).hexdigest(), 'success': value['success'], 'error': value.get('error'),
    'schema': {k: v for k, v in value.get('schema', {}).items() if k != 'base64'},
    'status': [m['decoded'] for m in value['messages'] if m['kind'] == 'status'],
    'block1Id': value.get('block1RpcId'), 'block1HeaderStateCaptured': value.get('block1HeaderStateCaptured'),
    'block1ProbeSkipped': value.get('block1ProbeSkipped'),
    'block1Sections': [{k: v for k, v in m.items() if k in ['sectionPresence', 'sections']} for m in value['messages'] if m['kind'] == 'block1']}, indent=2))
