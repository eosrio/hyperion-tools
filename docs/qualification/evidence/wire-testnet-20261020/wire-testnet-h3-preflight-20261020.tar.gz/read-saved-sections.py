"""Run official offline conversion against already captured original public input.

Only current native-account ABI/code metadata is requested; current metadata is never
used as historical/genesis ABI authority. No remote files are created.
"""
import base64, hashlib, json, pathlib, subprocess
root = pathlib.Path(__file__).resolve().parent
capture = json.loads((root / 'ship-preflight-20261020.json').read_bytes())
row = next(m for m in capture['messages'] if m['kind'] == 'block1')
payload = {'schema': capture['schema'], 'sections': row['sections'], 'captureSha256': hashlib.sha256((root / 'ship-preflight-20261020.json').read_bytes()).hexdigest()}
remote = r'''
import base64,hashlib,json,os,pathlib,subprocess,urllib.request,urllib.error,datetime
input_value = json.loads(base64.b64decode(PUBLIC_INPUT))
clio = '/opt/wire-sysio-1.0.0-6508c9e8/bin/clio'
assert hashlib.sha256(pathlib.Path(clio).read_bytes()).hexdigest() == '7485be43e7fd441f6a6e52f57b14f8859a768a59ae1226f80fbaad3c906f298e'
def blob(x):return {'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest(),'base64':base64.b64encode(x).decode()}
def raw(record):
 x=base64.b64decode(record['base64']);assert blob(x)==record;return x
out={'schemaVersion':1,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'actual6508-saved-input-official-converter-current-native-abi-only','captureSha256':input_value['captureSha256'],'conversions':[],'rpc':[],'changes':[]}
abi_fd=os.memfd_create('public-captured-abi',0);os.write(abi_fd,raw(input_value['schema']))
fds=[abi_fd]
def convert(args,extra=()):
 r=subprocess.run([clio,'convert']+args,capture_output=True,timeout=10,pass_fds=(abi_fd,)+tuple(extra))
 assert len(r.stdout)<=2097152 and len(r.stderr)<=262144,'converter bound exceeded'
 out['conversions'].append({'arguments':args,'exitCode':r.returncode,'stdout':blob(r.stdout),'stderr':blob(r.stderr)})
 if r.returncode or b'ERROR: Unable to convert' in r.stderr:return None
 return json.loads(r.stdout)
def unpack(typ,value):
 assert len(value)<=60000,'unpack raw argv bound exceeded'
 return convert(['unpack_hex',value.hex(),'--type',typ,'--abi-file','/proc/self/fd/'+str(abi_fd)])
def pack(typ,value):
 fd=os.memfd_create('public-converter-json',0);fds.append(fd);os.write(fd,json.dumps(value,separators=(',',':')).encode())
 return convert(['pack_hex','/proc/self/fd/'+str(fd),'--type',typ,'--abi-file','/proc/self/fd/'+str(abi_fd)],(fd,))
try:
 sections={name:raw(value) for name,value in input_value['sections'].items()}
 out['block']=unpack('signed_block',sections['block'])
 deltas=unpack('table_delta[]',sections['deltas']);out['declaredDeltaVector']=deltas
 if deltas is not None:
  encoded=pack('table_delta[]',deltas)
  if isinstance(encoded,str):
   repacked=bytes.fromhex(encoded);out['declaredDeltaVectorRoundtrip']={'equal':repacked==sections['deltas'],'repacked':blob(repacked),'originalBytes':len(sections['deltas']),'trailingBytesIfPrefix':len(sections['deltas'])-len(repacked) if sections['deltas'].startswith(repacked) else None}
  accounts=[]
  for tag,delta in deltas:
   if delta['name']=='account':
    for i,row in enumerate(delta['rows']):
     decoded=unpack('account',bytes.fromhex(row['data']))
     accounts.append({'ordinal':i,'present':row['present'],'originalRow':blob(bytes.fromhex(row['data'])),'decoded':decoded})
  out['genesisAccountRows']=accounts
 # sysio is present in the captured original block1 account rows. This is a bounded
 # current-head availability check, not a deployment/history inventory or ABI seed.
 for method,request in [('get_raw_abi',{'account_name':'sysio'}),('get_code_hash',{'account_name':'sysio'})]:
  body=json.dumps(request,separators=(',',':')).encode();url='http://127.0.0.1:58271/v1/chain/'+method
  try:
   with urllib.request.urlopen(urllib.request.Request(url,data=body,headers={'Content-Type':'application/json'}),timeout=5) as r: status=r.status;response=r.read(1048577)
  except urllib.error.HTTPError as e:status=e.code;response=e.read(1048577)
  assert len(response)<=1048576,'RPC response bound exceeded'
  record={'url':url,'request':blob(body),'response':blob(response),'status':status,'parsed':json.loads(response)}
  out['rpc'].append(record)
 out['success']=True
except Exception as e:out['success']=False;out['error']={'type':type(e).__name__,'message':str(e)}
finally:
 for fd in fds:os.close(fd)
 print(json.dumps(out,separators=(',',':')))
'''
script = ('PUBLIC_INPUT=' + repr(base64.b64encode(json.dumps(payload, separators=(',', ':')).encode()).decode()) + '\n' + remote).encode()
output = root / 'source-input-and-native-abi-20261020.json'
if output.exists(): raise SystemExit('refusing to overwrite evidence')
result = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-o','StrictHostKeyChecking=yes','root@100.97.129.48','python3','-'],input=script,capture_output=True,timeout=45)
if len(result.stdout)>20*1024*1024 or len(result.stderr)>65536:raise SystemExit('SSH receipt bound exceeded')
if result.returncode:raise SystemExit('SSH conversion failed: '+result.stderr.decode(errors='replace'))
value=json.loads(result.stdout)
with output.open('xb') as f:f.write(result.stdout)
print(json.dumps({'path':str(output),'bytes':len(result.stdout),'sha256':hashlib.sha256(result.stdout).hexdigest(),'success':value['success'],'error':value.get('error'),
 'block':value.get('block'),'deltaStreams':[{'name':d['name'],'rows':len(d['rows'])} for _,d in value.get('declaredDeltaVector',[])],
 'roundtrip':{k:v for k,v in value.get('declaredDeltaVectorRoundtrip',{}).items() if k!='repacked'},
 'genesisAccountNames':[r['decoded'][1]['name'] for r in value.get('genesisAccountRows',[]) if r['decoded']],
 'nativeAvailability':[{'url':r['url'],'status':r['status'],'account':r['parsed'].get('account_name'),'abiHash':r['parsed'].get('abi_hash'),'codeHash':r['parsed'].get('code_hash')} for r in value['rpc']]},indent=2))
