"""Bounded public SHiP status/block1 read using the running source's official clio.

No host files are created: clio ABI/JSON inputs use anonymous memfds only.
Original server messages and HTTP RPC response bytes are retained in the stdout receipt.
"""
import base64, datetime, hashlib, json, os, pathlib, socket, struct, subprocess, time, urllib.request

REV = '6508c9e8f4044df8d5acb082a7af3be6a80cd9a0'
CHAIN = '9ccd94e823fda51363bd4265ad618a909c4985c445078c79f8d030fe9697b71d'
NODE_SHA = 'c556257473bb460278208bd081cf370511ec9f1705a9c55d7535aa3a469d0fd0'
CLIO_SHA = '7485be43e7fd441f6a6e52f57b14f8859a768a59ae1226f80fbaad3c906f298e'
BIN = pathlib.Path('/opt/wire-sysio-1.0.0-6508c9e8/bin')
out = {'schemaVersion': 1, 'scope': 'actual-6508-testnet-read-only', 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
       'profileId': 'wire-sysio-6508c9e8-engineering-v1', 'sourceRevision': REV, 'chainId': CHAIN,
       'limits': {'socketDeadlineSecondsPerPhase': 15, 'maxMessageBytes': 2097152, 'maxAggregateTransportBytes': 4194304,
                  'officialClioRawArgumentBytes': 60000, 'rpcBodyBytes': 1048576}, 'rpc': [], 'transport': [], 'conversions': [], 'messages': [], 'changes': []}
def sha(x): return hashlib.sha256(x).hexdigest()
def blob(x): return {'bytes': len(x), 'sha256': sha(x), 'base64': base64.b64encode(x).decode()}
def rpc(method, value):
    raw_request = json.dumps(value, separators=(',', ':')).encode()
    url = 'http://127.0.0.1:58271/v1/chain/' + method
    with urllib.request.urlopen(urllib.request.Request(url, data=raw_request, headers={'Content-Type': 'application/json'}), timeout=5) as r:
        raw = r.read(1048577)
        if len(raw) > 1048576: raise RuntimeError('RPC response bound exceeded')
        row = {'url': url, 'request': blob(raw_request), 'response': blob(raw), 'status': r.status}
    out['rpc'].append(row)
    return json.loads(raw)
def binary_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''): h.update(block)
    return h.hexdigest()
s = None
fds = []
try:
    pids = subprocess.run(['pgrep', '-x', 'nodeop'], capture_output=True, text=True, timeout=3).stdout.split()
    if len(pids) > 8: raise RuntimeError('selected process search bound exceeded')
    selected = [int(p) for p in pids if os.readlink('/proc/' + p + '/exe') == str(BIN / 'nodeop')]
    if len(selected) != 1: raise RuntimeError('selected nodeop identity is not unique')
    pid = selected[0]
    if binary_sha(pathlib.Path('/proc') / str(pid) / 'exe') != NODE_SHA: raise RuntimeError('running binary digest changed')
    if binary_sha(BIN / 'clio') != CLIO_SHA: raise RuntimeError('official clio digest changed')
    info = rpc('get_info', {})
    if info.get('chain_id') != CHAIN or info.get('server_full_version_string') != 'v1.0.0-' + REV:
        raise RuntimeError('RPC source identity changed')
    out['pid'] = pid
    block1 = rpc('get_block', {'block_num_or_id': 1})
    out['block1RpcId'] = block1.get('id')
    if block1.get('block_num') != 1 or not isinstance(block1.get('id'), str): raise RuntimeError('RPC returned no exact block1 identity')
    s = socket.create_connection(('127.0.0.1', 58273), timeout=5)
    deadline = time.monotonic() + 15
    key = base64.b64encode(os.urandom(16)).decode()
    upgrade = ('GET / HTTP/1.1\r\nHost: 127.0.0.1:58273\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ' + key + '\r\nSec-WebSocket-Version: 13\r\n\r\n').encode()
    s.sendall(upgrade)
    received = b''
    while b'\r\n\r\n' not in received:
        s.settimeout(max(0.001, deadline - time.monotonic()))
        if time.monotonic() >= deadline: raise TimeoutError('upgrade deadline exceeded')
        part = s.recv(4096)
        if not part: raise RuntimeError('EOF during upgrade')
        received += part
        if len(received) > 65536: raise RuntimeError('upgrade headers exceeded bound')
    header, buffer = received.split(b'\r\n\r\n', 1)
    out['websocketUpgrade'] = {'request': blob(upgrade), 'responseHeaders': blob(header + b'\r\n\r\n')}
    if not header.startswith(b'HTTP/1.1 101 '): raise RuntimeError('SHiP websocket rejected')
    accept = base64.b64encode(hashlib.sha1((key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest())
    if b'sec-websocket-accept: ' + accept.lower() not in header.lower(): raise RuntimeError('websocket accept mismatch')
    aggregate = 0
    def read(n):
        global buffer
        while len(buffer) < n:
            remaining = deadline - time.monotonic()
            if remaining <= 0: raise TimeoutError('SHiP read deadline exceeded')
            s.settimeout(remaining)
            part = s.recv(min(65536, n - len(buffer)))
            if not part: raise RuntimeError('unexpected websocket EOF')
            buffer += part
        value, buffer = buffer[:n], buffer[n:]
        return value
    def send(payload, opcode=2):
        mask = os.urandom(4)
        n = len(payload)
        prefix = bytes([128 | opcode])
        if n < 126: prefix += bytes([128 | n])
        elif n < 65536: prefix += bytes([254]) + struct.pack('>H', n)
        else: prefix += bytes([255]) + struct.pack('>Q', n)
        raw = prefix + mask + bytes(value ^ mask[i % 4] for i, value in enumerate(payload))
        s.sendall(raw)
        out['transport'].append({'direction': 'client', 'opcode': opcode, **blob(raw)})
    def frame():
        global aggregate
        chunks = []
        initial = None
        size = 0
        while True:
            prefix = read(2)
            a, b = prefix
            if a & 0x70 or b & 128: raise RuntimeError('unsupported/masked server frame')
            n = b & 127
            if n == 126:
                length = read(2); prefix += length; n = struct.unpack('>H', length)[0]
            elif n == 127:
                length = read(8); prefix += length; n = struct.unpack('>Q', length)[0]
            if n > 2097152 or size + n > 2097152 or aggregate + len(prefix) + n > 4194304:
                raise RuntimeError('SHiP transport/message size bound exceeded')
            data = read(n)
            aggregate += len(prefix) + n
            opcode = a & 15
            out['transport'].append({'direction': 'server', 'opcode': opcode, **blob(prefix + data)})
            if opcode == 9:
                if n > 125 or not a & 128: raise RuntimeError('invalid ping')
                send(data, 10); continue
            if opcode == 8: raise RuntimeError('server closed before selected result')
            if initial is None:
                if opcode not in (1, 2): raise RuntimeError('unexpected message opcode')
                initial = opcode
            elif opcode != 0: raise RuntimeError('unexpected continuation opcode')
            chunks.append(data); size += n
            if a & 128: return initial, b''.join(chunks)
    opcode, schema = frame()
    if opcode != 1: raise RuntimeError('expected original text ABI handshake')
    schema_json = json.loads(schema)
    if not isinstance(schema_json, dict) or not isinstance(schema_json.get('structs'), list): raise RuntimeError('malformed schema handshake')
    out['schema'] = blob(schema)
    abi_fd = os.memfd_create('wire-public-ship-abi', 0); fds.append(abi_fd); os.write(abi_fd, schema)
    def convert(args, extra_fds=()):
        result = subprocess.run([str(BIN / 'clio'), 'convert'] + args, capture_output=True, timeout=10,
                                pass_fds=(abi_fd,) + tuple(extra_fds))
        if len(result.stdout) > 2097152 or len(result.stderr) > 262144: raise RuntimeError('official converter output bound exceeded')
        out['conversions'].append({'arguments': args, 'exitCode': result.returncode,
                                   'stdout': blob(result.stdout), 'stderr': blob(result.stderr)})
        if result.returncode or b'ERROR: Unable to convert' in result.stderr: raise RuntimeError('official converter rejected input')
        return json.loads(result.stdout)
    def pack(value):
        payload = json.dumps(value, separators=(',', ':')).encode()
        fd = os.memfd_create('wire-public-ship-request', 0); fds.append(fd); os.write(fd, payload)
        result = convert(['pack_hex', '/proc/self/fd/' + str(fd), '--type', 'request', '--abi-file', '/proc/self/fd/' + str(abi_fd)], (fd,))
        return bytes.fromhex(result)
    def decode(raw):
        if len(raw) > 60000: raise RuntimeError('official converter argv bound exceeded; original bytes retained')
        return convert(['unpack_hex', raw.hex(), '--type', 'result', '--abi-file', '/proc/self/fd/' + str(abi_fd)])
    status_value = ['get_status_request_v0', {}]
    status_request = pack(status_value)
    send(status_request)
    _, status_raw = frame()
    status = decode(status_raw)
    out['messages'].append({'kind': 'status', 'requestValue': status_value, 'request': blob(status_request), 'response': blob(status_raw), 'decoded': status})
    if not isinstance(status, list) or status[0] != 'get_status_result_v0' or status[1].get('chain_id') != CHAIN:
        raise RuntimeError('unselected status chain/type')
    state = status[1]
    out['stateRangeIncludesBlock1'] = state.get('chain_state_begin_block', 0) <= 1 < state.get('chain_state_end_block', 0)
    out['traceRangeIncludesBlock1'] = state.get('trace_begin_block', 0) <= 1 < state.get('trace_end_block', 0)
    if out['stateRangeIncludesBlock1']:
        request_value = ['get_blocks_request_v0', {'start_block_num': 1, 'end_block_num': 2, 'max_messages_in_flight': 1,
            'have_positions': [], 'irreversible_only': True, 'fetch_block': True, 'fetch_traces': False, 'fetch_deltas': True}]
        request = pack(request_value)
        deadline = time.monotonic() + 15
        send(request)
        _, result_raw = frame()
        row = {'kind': 'block1', 'requestValue': request_value, 'request': blob(request), 'response': blob(result_raw)}
        out['messages'].append(row)
        result = decode(result_raw); row['decoded'] = result
        if not isinstance(result, list) or result[0] != 'get_blocks_result_v0': raise RuntimeError('unexpected selected block result type')
        value = result[1]
        if value.get('this_block', {}).get('block_num') != 1 or value['this_block'].get('block_id') != block1['id']:
            raise RuntimeError('SHiP block1 identity does not match actual RPC')
        if value.get('traces') is not None: raise RuntimeError('traces unexpectedly present although fetch disabled')
        row['sectionPresence'] = {name: value.get(name) is not None for name in ['block', 'traces', 'deltas']}
        row['sections'] = {name: blob(bytes.fromhex(value[name])) for name in ['block', 'deltas'] if value.get(name) is not None}
        ack_value = ['get_blocks_ack_request_v0', {'num_messages': 1}]
        ack = pack(ack_value); send(ack)
        row['ack'] = {'value': ack_value, **blob(ack)}
        out['block1HeaderStateCaptured'] = value.get('block') is not None and value.get('deltas') is not None
        out['initialTableCompletenessValidated'] = False
    else:
        out['block1ProbeSkipped'] = 'actual retained chain-state range excludes block1'
        out['block1HeaderStateCaptured'] = False
    final_info = rpc('get_info', {})
    if final_info.get('chain_id') != CHAIN or final_info.get('server_full_version_string') != 'v1.0.0-' + REV:
        raise RuntimeError('source identity changed after capture')
    if binary_sha(pathlib.Path('/proc') / str(pid) / 'exe') != NODE_SHA: raise RuntimeError('selected process changed during capture')
    out['success'] = True
except Exception as error:
    out['success'] = False
    out['error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    if s is not None: s.close()
    for fd in fds: os.close(fd)
    out['completedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(json.dumps(out, separators=(',', ':')))
