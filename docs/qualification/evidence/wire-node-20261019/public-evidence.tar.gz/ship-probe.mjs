import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';

const destination = process.argv[2];
assert(destination, 'Provide an owned evidence output path');
const socket = new WebSocket('ws://127.0.0.1:18080');
const timeout = setTimeout(() => {socket.close(); throw new Error('Timed out waiting for the Wire SHiP ABI');}, 15_000);
socket.addEventListener('error', () => {clearTimeout(timeout); throw new Error('Wire SHiP WebSocket failed');});
socket.addEventListener('message', async (event) => {
  clearTimeout(timeout);
  const text = typeof event.data === 'string' ? event.data : Buffer.from(await event.data.arrayBuffer()).toString('utf8');
  const abi = JSON.parse(text);
  assert(Array.isArray(abi.structs) && Array.isArray(abi.variants));
  const row = abi.structs.find((value) => value.name === 'contract_row_kv_v0');
  const index = abi.structs.find((value) => value.name === 'contract_index_kv_v0');
  assert.deepEqual(row?.fields.map((field) => field.name), ['code', 'payer', 'table_id', 'key', 'value']);
  assert.deepEqual(index?.fields.map((field) => field.name), ['code', 'payer', 'table_id', 'sec_key', 'pri_key']);
  writeFileSync(destination, text + '\n', {mode: 0o600});
  const result = {status: 'passed', url: 'ws://127.0.0.1:18080', abiVersion: abi.version, structs: abi.structs.length, rowFields: row.fields, indexFields: index.fields, sha256: createHash('sha256').update(text + '\n').digest('hex')};
  writeFileSync(destination + '.receipt.json', JSON.stringify(result, null, 2) + '\n', {mode: 0o600});
  console.log(JSON.stringify(result));
  socket.close();
}, {once: true});
