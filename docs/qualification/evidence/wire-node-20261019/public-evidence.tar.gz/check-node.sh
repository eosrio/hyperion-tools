#!/usr/bin/env bash
set -euo pipefail
umask 077
base=/srv/hyperion-wire-testnet/20261019-node-setup
evidence="$base/evidence"
unit=hyperion-wire-node42.service
binary="$base/runtime/wire-sysio/bin/nodeop"
node=/var/snap/docker/common/hyperion-qualification/run-20261019-195-208/tools/node-v24.19.0-linux-x64/bin/node
test -x "$node"
curl --fail --silent --show-error --max-time 5 http://127.0.0.1:18888/v1/chain/get_info > "$evidence/rpc-before-restart.json"
"$node" "$evidence/ship-probe.mjs" "$evidence/ship-abi.json"
systemctl stop "$unit"
test "$(systemctl show "$unit" -p MainPID --value)" = 0
systemctl show "$unit" -p ActiveState -p SubState -p ExecMainCode -p ExecMainStatus > "$evidence/clean-stop.txt"
test "$(systemctl show "$unit" -p ExecMainStatus --value)" = 0
set +e
runuser -u wire-hyperion42 -- "$binary" --config-dir "$base/config" --data-dir "$base/data" --extract-genesis-json "$base/data/public-genesis.json" > "$evidence/genesis-extraction.log" 2>&1
extract_status=$?
set -e
# Wire v1.0.0 terminates successful export with extract_genesis_state_exception.
if test "$extract_status" != 0; then
  test "$extract_status" = 254
  grep -q '3100005 extract_genesis_state_exception: Extracted genesis state from blocks.log' "$evidence/genesis-extraction.log"
fi
python3 - "$base/data/public-genesis.json" <<'PY'
import json,sys
with open(sys.argv[1]) as f:
    genesis=json.load(f)
assert genesis.get('initial_key') and genesis.get('initial_finalizer_key')
assert not any(value.startswith('PVT_') for value in genesis.values() if isinstance(value,str))
PY
cp "$base/data/public-genesis.json" "$evidence/genesis.json"
systemctl start "$unit"
python3 - <<'PY'
import json,time,urllib.request,pathlib
base=pathlib.Path('/srv/hyperion-wire-testnet/20261019-node-setup')
before=json.loads((base/'evidence/rpc-before-restart.json').read_text())
for attempt in range(20):
    try:
        with urllib.request.urlopen('http://127.0.0.1:18888/v1/chain/get_info',timeout=3) as response:
            after=json.load(response)
        if after['chain_id']==before['chain_id'] and after['head_block_num']>before['head_block_num'] and after['last_irreversible_block_num']>=before['last_irreversible_block_num']:
            break
    except OSError:
        pass
    time.sleep(1)
else:
    raise SystemExit('Restart did not preserve chain identity and advance prior head/finality')
(base/'evidence/rpc-after-restart.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={
    'status':'passed','candidateOnly':True,'chainId':after['chain_id'],
    'sourceCommit':'7dede884e0150d36fa788e85a119e10653ade8ca',
    'version':after['server_full_version_string'],
    'before':{k:before[k] for k in ['head_block_num','last_irreversible_block_num','head_block_time']},
    'after':{k:after[k] for k in ['head_block_num','last_irreversible_block_num','head_block_time']},
    'cleanRestart':True,'contractDeployment':'not performed','pluginIntegration':'not performed',
    'launchProfile':'not selected','note':'Empty single-producer engineering node; not Wire release qualification.'
}
(base/'evidence/node-acceptance.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
PY
systemctl show "$unit" -p ActiveState -p SubState -p MainPID -p MemoryCurrent -p MemoryMax -p CPUQuotaPerSecUSec -p RuntimeMaxUSec > "$evidence/service-final.txt"
stat -c '%a %U %n' "$base/config/default_signature_providers.json" > "$evidence/key-permissions.txt"
sha256sum -c "$evidence/preexisting-binaries.sha256"
