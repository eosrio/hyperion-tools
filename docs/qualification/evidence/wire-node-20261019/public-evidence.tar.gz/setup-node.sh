#!/usr/bin/env bash
set -euo pipefail
base=/srv/hyperion-wire-testnet/20261019-node-setup
unit=hyperion-wire-node42.service
account=wire-hyperion42
binary="$base/runtime/wire-sysio/bin/nodeop"
expected=ad275fff367f903b0a4a2a8d402f1d52e4a709ae9a4d362654b5315617db189e
test "$(sha256sum "$binary" | cut -d ' ' -f1)" = "$expected"
test "$("$binary" --full-version)" = v1.0.0-7dede884e0150d36fa788e85a119e10653ade8ca
test "$(systemctl show "$unit" -p LoadState --value)" = not-found
test ! -e "$base/config/config.ini"
if getent passwd "$account" >/dev/null; then
  echo 'Refusing to reuse an existing service account' >&2
  exit 1
fi
python3 - <<'PY'
import socket
for port in (18888, 18080, 19876):
    with socket.socket() as s:
        s.bind(('127.0.0.1', port))
print('Dedicated loopback ports are free')
PY
useradd --system --user-group --no-create-home --home-dir "$base" --shell /usr/sbin/nologin "$account"
chmod 755 /srv/hyperion-wire-testnet "$base" "$base/runtime"
install -d -m 700 -o "$account" -g "$account" "$base/config" "$base/data"
umask 077
cat > "$base/config/config.ini" <<'CONFIG'
plugin = sysio::chain_api_plugin
plugin = sysio::producer_plugin
plugin = sysio::state_history_plugin
producer-name = sysio
enable-stale-production = true
http-server-address = 127.0.0.1:18888
state-history-endpoint = 127.0.0.1:18080
p2p-listen-endpoint = 127.0.0.1:19876
allowed-connection = none
chain-state-db-size-mb = 512
chain-state-db-guard-size-mb = 64
chain-threads = 2
vote-threads = 1
net-threads = 1
http-threads = 1
read-only-threads = 0
resource-monitor-space-absolute-gb = 8
trace-history = true
chain-state-history = true
finality-data-history = true
CONFIG
chown "$account:$account" "$base/config/config.ini"
cat > "/etc/systemd/system/$unit" <<UNIT
[Unit]
Description=Isolated Wire engineering node for Hyperion tools issue 42
After=network.target

[Service]
Type=simple
User=$account
Group=$account
WorkingDirectory=$base
ExecStart=$binary --config-dir $base/config --data-dir $base/data
Restart=no
TimeoutStopSec=90
KillSignal=SIGINT
MemoryHigh=3G
MemoryMax=4G
CPUQuota=200%
TasksMax=128
Nice=10
RuntimeMaxSec=6h
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
ReadWritePaths=$base/config $base/data
RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6
StandardOutput=journal
StandardError=journal
SyslogIdentifier=hyperion-wire-node42
LogRateLimitIntervalSec=30s
LogRateLimitBurst=500

[Install]
WantedBy=multi-user.target
UNIT
chmod 644 "/etc/systemd/system/$unit"
systemctl daemon-reload
systemctl start "$unit"
systemctl show "$unit" -p ActiveState -p SubState -p MainPID -p MemoryMax -p CPUQuotaPerSecUSec -p RuntimeMaxUSec
echo 'Service started without enabling boot startup; keys remain in its owner-only config directory.'
